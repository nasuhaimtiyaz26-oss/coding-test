/* =========================================================
   DATA + INTERACTIONS
   OWID Grapher CSV endpoints are public and work client-side,
   so no backend is required for GitHub Pages.
   ========================================================= */

const OWID = "https://ourworldindata.org/grapher/";

/* Small mobile navigation */
const menu = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
menu?.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menu.setAttribute("aria-expanded", String(open));
});
navLinks?.querySelectorAll("a").forEach(a => a.addEventListener("click", () => navLinks.classList.remove("open")));

/* Parse an OWID CSV response without requiring another library. */
function parseCSV(text) {
  const rows = [];
  let row = [], cell = "", quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i], next = text[i + 1];
    if (c === '"' && quoted && next === '"') { cell += '"'; i++; }
    else if (c === '"') quoted = !quoted;
    else if (c === "," && !quoted) { row.push(cell); cell = ""; }
    else if ((c === "\n" || c === "\r") && !quoted) {
      if (c === "\r" && next === "\n") i++;
      row.push(cell); if (row.some(v => v !== "")) rows.push(row);
      row = []; cell = "";
    } else cell += c;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows;
}

async function getOWID(slug) {
  const res = await fetch(`${OWID}${slug}.csv`);
  if (!res.ok) throw new Error(`Could not load ${slug}`);
  const rows = parseCSV(await res.text());
  const headers = rows.shift();
  return rows.map(r => Object.fromEntries(headers.map((h,i) => [h, r[i]])));
}

function findColumn(row, tests) {
  return Object.keys(row).find(k => tests.some(t => k.toLowerCase().includes(t)));
}
function worldOnly(rows) {
  return rows.filter(r => (r.Entity || "").toLowerCase() === "world");
}
function latest(rows) {
  return [...rows].filter(r => r.Year && !Number.isNaN(Number(r.Year))).sort((a,b)=>Number(a.Year)-Number(b.Year)).at(-1);
}
function series(rows, valueColumn) {
  return rows.filter(r => r.Year && r[valueColumn] !== "" && !Number.isNaN(Number(r[valueColumn])))
    .sort((a,b)=>Number(a.Year)-Number(b.Year));
}
function compact(n) {
  if (!Number.isFinite(n)) return "—";
  const a = Math.abs(n);
  if (a >= 1e6) return (n/1e6).toFixed(1) + "M";
  if (a >= 1e3) return (n/1e3).toFixed(1) + "k";
  return n.toLocaleString(undefined,{maximumFractionDigits:0});
}

const chartBase = {
  responsive: true, maintainAspectRatio: false,
  interaction: { mode: "index", intersect: false },
  plugins: {
    legend: { labels: { color: "#c8d6cf", usePointStyle: true, boxWidth: 8, font: {size: 10, weight: 700} } },
    tooltip: { backgroundColor: "rgba(3,17,11,.94)", padding: 12, cornerRadius: 12 }
  },
  scales: {
    x: { ticks: {color:"#789084", maxTicksLimit:8, font:{size:9}}, grid:{display:false} },
    y: { ticks: {color:"#789084", font:{size:9}}, grid:{color:"rgba(255,255,255,.07)"} }
  }
};

async function loadDashboard() {
  const status = document.getElementById("dataStatus");
  try {
    /*
      1) Primary energy: fossil / nuclear / renewables.
         This is the OWID Grapher chart "primary-energy-from-fossil-nuclear-renewables".
      2) Global primary energy by source for total consumption.
      3) Electricity production from fossil / nuclear / renewables.
    */
    const [primary, consumption, electricity] = await Promise.all([
      getOWID("primary-energy-from-fossil-nuclear-renewables"),
      getOWID("global-primary-energy-by-source"),
      getOWID("elec-fossil-nuclear-renewables")
    ]);

    const pWorld = worldOnly(primary);
    const cWorld = worldOnly(consumption);
    const eWorld = worldOnly(electricity);

    const pSample = pWorld[0] || {};
    const pCols = {
      fossil: findColumn(pSample, ["fossil"]),
      nuclear: findColumn(pSample, ["nuclear"]),
      renewable: findColumn(pSample, ["renewable"])
    };

    const cSample = cWorld[0] || {};
    const cCol = findColumn(cSample, ["primary energy", "energy consumption", "total"]);
    const eSample = eWorld[0] || {};
    const eCols = {
      fossil: findColumn(eSample, ["fossil"]),
      nuclear: findColumn(eSample, ["nuclear"]),
      renewable: findColumn(eSample, ["renewable"])
    };

    const lastP = latest(pWorld);
    document.getElementById("renewableMetric").textContent = compact(Number(lastP?.[pCols.renewable]));
    document.getElementById("fossilMetric").textContent = compact(Number(lastP?.[pCols.fossil]));
    document.getElementById("nuclearMetric").textContent = compact(Number(lastP?.[pCols.nuclear]));
    document.getElementById("yearMetric").textContent = lastP?.Year || "—";

    /* Chart 1: Renewable vs Fossil */
    const pYears = pWorld.filter(r => r[pCols.renewable] && r[pCols.fossil]);
    new Chart(document.getElementById("renewableFossilChart"), {
      type: "line",
      data: {
        labels: pYears.map(r=>r.Year),
        datasets: [
          { label:"Renewable energy", data:pYears.map(r=>Number(r[pCols.renewable])), borderColor:"#56e49a", backgroundColor:"rgba(86,228,154,.13)", fill:true, tension:.35, pointRadius:0 },
          { label:"Fossil fuels", data:pYears.map(r=>Number(r[pCols.fossil])), borderColor:"#d2a66e", backgroundColor:"rgba(210,166,110,.08)", fill:true, tension:.35, pointRadius:0 }
        ]
      }, options: chartBase
    });

    /* Chart 2: Global energy consumption */
    const cYears = series(cWorld, cCol);
    new Chart(document.getElementById("consumptionChart"), {
      type:"line",
      data:{labels:cYears.map(r=>r.Year), datasets:[{
        label:"Global primary energy",
        data:cYears.map(r=>Number(r[cCol])),
        borderColor:"#bdf8d8", backgroundColor:"rgba(86,228,154,.13)", fill:true, tension:.35, pointRadius:0
      }]},
      options: chartBase
    });

    /* Chart 3: Electricity generation */
    const eYears = eWorld.filter(r=>r[eCols.fossil] && r[eCols.nuclear] && r[eCols.renewable]);
    new Chart(document.getElementById("electricityChart"), {
      type:"line",
      data:{labels:eYears.map(r=>r.Year), datasets:[
        {label:"Renewables",data:eYears.map(r=>Number(r[eCols.renewable])),borderColor:"#56e49a",tension:.3,pointRadius:0},
        {label:"Fossil fuels",data:eYears.map(r=>Number(r[eCols.fossil])),borderColor:"#d2a66e",tension:.3,pointRadius:0},
        {label:"Nuclear",data:eYears.map(r=>Number(r[eCols.nuclear])),borderColor:"#b9c6ff",tension:.3,pointRadius:0}
      ]},
      options: chartBase
    });

    status.textContent = `Connected • OWID Energy data loaded for the World • latest available year: ${lastP?.Year || "current dataset"}`;
  } catch (error) {
    console.error(error);
    status.innerHTML = `Data connection could not be loaded in this browser. The official source remains available at <a href="https://ourworldindata.org/energy" target="_blank" rel="noopener">Our World in Data – Energy</a>.`;
  }
}

loadDashboard();
