# IMPORTANCE OF SAFE ENERGY

A modern responsive environmental technology / data visualization website built with:

- HTML
- CSS
- JavaScript
- Chart.js
- Our World in Data Energy dataset

## Files

```text
index.html
style.css
script.js
README.md
```

## Data

The dashboard requests data client-side from Our World in Data Grapher CSV endpoints. This means no backend is required and the site can run on GitHub Pages.

Official source:
https://ourworldindata.org/energy

The project uses OWID Energy visualizations/datasets for global primary energy and electricity generation. Data is not hard-coded into the dashboard.

## Run locally

Open `index.html` in a browser. If your browser blocks remote requests when opening the file directly, use a simple local server such as VS Code Live Server.

## GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save.
7. GitHub will provide the Pages URL.

## Attribution

Energy data and visualizations: Our World in Data, licensed under CC BY where applicable. Some underlying third-party data has its own licensing terms; see the official OWID source and dataset documentation.

## Important

The hero/background photography uses remote Unsplash image URLs for a polished presentation. If you want a fully self-contained/offline version, download appropriately licensed images and replace the URLs in `style.css`.
